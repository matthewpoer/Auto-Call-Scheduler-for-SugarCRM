<?php
$mod_strings['LBL_SCHEDULER_GROUP_TITLE'] = 'Call Auto-Scheduler';
$mod_strings['LBL_SCHEDULER_ENTRY_TITLE'] = 'Activate and Configure';
$mod_strings['LBL_SCHEDULER_ENTRY_DESC'] = 'Setup when the scheduler should create calls for new Contacts and Leads';
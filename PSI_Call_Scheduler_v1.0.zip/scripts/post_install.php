<?php
function post_install(){
    echo "You may want to <a href='index.php?module=Contacts&action=Configure_Call_Scheduler'>Activate and Configure</a> the Auto-Scheduler now.";
}
?>